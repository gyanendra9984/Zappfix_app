import { View, Text, TextInput, StyleSheet } from 'react-native'
import React from 'react'

export default function FeaturedRow(){
    return (
        <View>
            <Text>FeaturedRow</Text>
        </View>
    )
}